# aaronudho.com

No build step, no dependencies. Edit, commit, live in about a minute.

```
index.html     the whole site
CNAME          points GitHub Pages at aaronudho.com, don't delete
products/      digital product covers
photos/        photos of you
```

## Adding a digital product cover

Drop the image into `products/` named with the next number: `3.jpg`, then `4.jpg`, and so on.
It appears in the rotating cover shelf automatically. Nothing to edit.

## Adding a photo of yourself

Drop the image into `photos/` named `2.jpg`, then `3.jpg`, and so on.
The arrows under the photo let visitors step through them.

## The one rule

**Numbers must run 1, 2, 3 with no gaps.** The page tries each number in order and stops at the
first one missing, so if you have 1, 2 and 4, the 4 never shows. `.jpg`, `.jpeg`, `.png` and
`.webp` all work. Keep covers portrait and photos square, and keep each file under about 300KB
so the page stays fast.

## Email

`info@aaronudho.com` runs on iCloud+ Custom Email Domain. Sends and receives in Apple Mail.

## Previewing before you upload

Unzip the whole folder and open `index.html` from inside it. Opening the HTML on its own
won't find the image folders.
